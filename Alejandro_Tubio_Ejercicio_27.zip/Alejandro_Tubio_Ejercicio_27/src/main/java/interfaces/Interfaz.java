package interfaces;

public interface Interfaz {

}
