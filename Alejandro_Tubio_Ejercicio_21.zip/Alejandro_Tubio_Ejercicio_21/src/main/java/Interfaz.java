
public interface Interfaz {
	long calcularPrecio(long precioTotal);
}
